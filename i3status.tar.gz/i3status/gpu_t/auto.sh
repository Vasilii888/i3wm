#!/bin/bash

watch -n 5 sh ~/.config/i3status/gpu_t/script.sh
